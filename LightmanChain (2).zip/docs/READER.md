# LightmanChain Repo Guide

This repository contains the full codebase for the LightmanChain project, a permissioned blockchain using Hyperledger Fabric.