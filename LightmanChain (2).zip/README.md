# LightmanChain
Permissioned blockchain network using Hyperledger Fabric for insurance tokenization.